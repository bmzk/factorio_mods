
function creat_chest(chest_name, w, h)
    return {
        --item
    {
        type = "item",
        name = chest_name,
        icon = "__fpc_BigChest__/img/"..chest_name.."_0.png",
        icon_size = 32,
        --flags = {"goes-to-quickbar"},
        subgroup = "storage",
        order = "a[items]-b["..chest_name.."]",
        place_result = chest_name,
        stack_size = 10
    },
    --recipe
    {   
        type = "recipe",
        name = chest_name,
        ingredients =   {{"iron-plate", 1 }},
        result = chest_name
    },
    --entry
    {
        type = "logistic-container",
        name = chest_name,
        icon = "__fpc_BigChest__/img/"..chest_name.."_0.png",
        icon_size = 32,--32
        flags = {"placeable-neutral", "player-creation"},
        minable = {mining_time = 0.1, result = chest_name},
        max_health = 5000,
        corpse = "small-remnants",
        open_sound = { filename = "__base__/sound/metallic-chest-open.ogg", volume=0.65 },
        close_sound = { filename = "__base__/sound/metallic-chest-close.ogg", volume = 0.7 },
        resistances =
        {
          {
            type = "fire",
            percent = 90
          },
          {
            type = "impact",
            percent = 60
          }
        },
        collision_box = {{-(w/2-0.15), -(h/2-0.15)}, {(w/2-0.15), (h/2-0.15)}},
        selection_box = {{-w/2, -h/2}, {w/2, h/2}},
        fast_replaceable_group = "container",
        inventory_size = 1000,
        logistic_mode = "passive-provider",
        vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
        picture =
        {
          filename = "__fpc_BigChest__/img/"..chest_name.."_1.png",
          priority = "extra-high",
          width = w * 32 ,--32
          height = h*32,--32
          shift = {0,0}---{左右为，正则图像右移；上下，为正则图像下移}
        },
        circuit_wire_connection_point = circuit_connector_definitions["chest"].points,
        circuit_connector_sprites = circuit_connector_definitions["chest"].sprites,
        circuit_wire_max_distance = default_circuit_wire_max_distance
    },
    }
end

data:extend(creat_chest("chest_1_36" ,  1, 36))
data:extend(creat_chest("chest_4_2"  ,  4,  2))
data:extend(creat_chest("chest_20_20", 20, 20))
data:extend(creat_chest("chest_25_2" , 25,  2))

  
  
  
  