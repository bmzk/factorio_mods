
----内燃机
data.raw["recipe"]["engine-unit"].ingredients={ 
    {"steel-plate", 5},
    {"electronic-circuit", 1}}
----电动机
data.raw["recipe"]["electric-engine-unit"].ingredients={ 
    {"engine-unit", 1},
    {"electronic-circuit", 2}}